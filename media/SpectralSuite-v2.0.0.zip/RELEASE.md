
- 2.0.0
    * Simplified plugins
    * Using JUCE framework for the UI
    * Improved general stability